#ifndef LED_DATA_H_
#define LED_DATA_H_

typedef struct LED_Data {
  uint8_t r;
  uint8_t g;
  uint8_t b;
} LED_Data;

#endif
